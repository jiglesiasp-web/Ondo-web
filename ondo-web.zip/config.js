// Configuración pública del formulario del piloto.
// La "anon key" de Supabase es pública por diseño: la seguridad la da la política RLS
// de supabase/piloto_leads.sql (solo permite insertar, nunca leer).
// Rellena estos dos valores con los de TU proyecto de producción (región UE).
window.ONDO_CONFIG = {
  supabaseUrl: "",       // p. ej. https://xxxxxxxx.supabase.co
  supabaseAnonKey: ""    // Settings > API > anon public
};
